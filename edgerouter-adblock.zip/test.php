<?php
$num = 5;
$float = floatval($num);
echo round($float,2);

?>
